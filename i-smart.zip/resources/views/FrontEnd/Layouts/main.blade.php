@include('FrontEnd.Layouts.header')
@yield('main.container')
@include('FrontEnd.Layouts.footer')

