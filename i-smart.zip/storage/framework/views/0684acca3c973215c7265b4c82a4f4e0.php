<!DOCTYPE html>
<html>

<head>
    <title>Login Form</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="<?php echo e(asset('asset/assets/img/logo.jpg')); ?>">
    <link rel="icon" href="<?php echo e(asset('asset/assets/img/logo.jpg')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('asset/assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/assets/css/fontawesome_all.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('asset/assets/css/ma5-menu.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/assets/css/responsive.css')); ?>">
</head>

<body>
    
    <div class="login-container log">
        <h1>Login</h1>
        <?php if(Auth::id()): ?>
            <div class="alert alert-success" role="alert">
                You've logged in, Back to <a href="/">Home</a>, or <a href="/logout">Logout</a>
            </div>
        <?php endif; ?>
        <?php if(Session::get('message')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="" class="<?php echo e(Auth::id() ? 'd-none' : ''); ?>">
            <?php echo csrf_field(); ?>
            
            <label class="control-label" for="number">ফোন
                নাম্বার</label>
            <input id="number" name="number" class="form-control" placeholder="আপনার ফোন নাম্বার" type="number"
                required>
            <br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Livestock\i-smart\resources\views/auth/login.blade.php ENDPATH**/ ?>