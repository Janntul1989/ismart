<?php echo $__env->make('FrontEnd.Layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main.container'); ?>
<?php echo $__env->make('FrontEnd.Layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\Livestock\i-smart\resources\views/Frontend/layouts/main.blade.php ENDPATH**/ ?>